from playsound import playsound

def play():
    """Play sound
    Parameters:
        none
    Return:
        None
    """
    playsound("../packagefiles/rocket.mp3")